//
//  ScreenSize.swift
//  AnimationNotification
//
//  Created by Maxime Lathiere on 03/07/2022.
//

import SwiftUI

enum Screen {
    static let width = UIScreen.main.bounds.width
    static let height = UIScreen.main.bounds.height
}

//
//  AnimationNotificationApp.swift
//  AnimationNotification
//
//  Created by Maxime Lathiere on 03/07/2022.
//

import SwiftUI

@main
struct AnimationNotificationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

//
//  ContentView.swift
//  AnimationNotification
//
//  Created by Maxime Lathiere on 03/07/2022.
//

import SwiftUI

struct ContentView: View {
    @State private var  isNotificationPresented = false
    
    var body: some View {
        Button("Push to preview") {
            withAnimation(.interpolatingSpring(stiffness: 100, damping: 10)) {
                isNotificationPresented.toggle()
            }
        }
        .buttonStyle(.borderedProminent)
        .controlSize(.large)
        .frame(maxWidth: .infinity)
        .overlay {
            NotificationView()
                .offset(y: notificationOffset)
        }
    }
    
    private var notificationOffset: Double {
        let height = UIScreen.main.bounds.height
        return isNotificationPresented ? (-height / 2.5) : -height
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


//
//  ContentView.swift
//  AnimationNotification
//
//  Created by Maxime Lathiere on 03/07/2022.
//

import SwiftUI

struct ContentView: View {
    @State private var  isActive = false
    
    var body: some View {
        Button("Push to preview") {
            withAnimation(.interpolatingSpring(stiffness: 100, damping: 10)) {
                isActive.toggle()
            }
        }
        .buttonStyle(.borderedProminent)
        .controlSize(.large)
        .overlay {
            NotificationView()
                .offset(y: offset)
        }
    }
    
    var offset: Double {
        isActive ? -Screen.height / 2.5 : -Screen.height
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


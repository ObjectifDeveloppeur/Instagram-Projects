//
//  NotificationView.swift
//  AnimationNotification
//
//  Created by Maxime Lathiere on 03/07/2022.
//

import SwiftUI

struct NotificationView: View {
    var body: some View {
        Text("Sucess")
            .bold()
            .frame(maxWidth: .infinity)
            .frame(height: 60)
            .background(.green.gradient)
            .cornerRadius(12)
            .foregroundColor(.white)
            .padding(.horizontal)
    }
}

struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}

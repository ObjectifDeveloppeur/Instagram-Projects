//
//  ContentView.swift
//  IndicateurChargement
//
//  Created by Maxime Lathiere on 15/11/2022.
//

import SwiftUI

struct ContentView: View {
    @State private var animationAmount = 1.0
    
    var body: some View {
        Text("Sauvegarde...")
            .font(.title3.bold())
            .frame(width: 200, height: 200)
            .background(.ultraThickMaterial, in: Circle())
            .overlay { animatedRing }
            .foregroundColor(.secondary)
            .shadow(radius: 7)
            .onAppear(perform: startAnimation)
    }
    
    private var animatedRing: some View {
        Circle()
            .stroke()
            .scaleEffect(animationAmount)
            .opacity(2 - animationAmount)
    }
    
    private func startAnimation() {
        withAnimation(.easeInOut(duration: 1)
                      .repeatForever(autoreverses: false)) {
            animationAmount += 1
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ZStack {
            Image("photo")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .opacity(0.4)
            
            ContentView()
        }
    }
}

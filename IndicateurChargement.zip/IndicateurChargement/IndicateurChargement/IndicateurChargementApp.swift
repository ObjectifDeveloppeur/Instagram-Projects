//
//  IndicateurChargementApp.swift
//  IndicateurChargement
//
//  Created by Maxime Lathiere on 15/11/2022.
//

import SwiftUI

@main
struct IndicateurChargementApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  TextField_SecureFieldApp.swift
//  TextField&SecureField
//
//  Created by Maxime Lathiere on 04/07/2022.
//

import SwiftUI

@main
struct TextField_SecureFieldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

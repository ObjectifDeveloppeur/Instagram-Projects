//
//  ContentView.swift
//  TextField&SecureField
//
//  Created by Maxime Lathiere on 04/07/2022.
//

import SwiftUI

struct ContentView: View {
    @State private var email = ""
    @State private var password = ""
    
    var body: some View {
        VStack(spacing: 30) {
            TextField("Email",text: $email, prompt: Text("Enter your email"))
                .textFieldStyle(CustomTextFieldStyle(keyboardType: .emailAddress))
            
            
            SecureField("Password",
                        text: $password,
                        prompt: Text("Enter your password"))
                .textFieldStyle(CustomTextFieldStyle())
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
    }
}


struct CustomTextFieldStyle: TextFieldStyle {
    let keyboardType: UIKeyboardType
    
    init(keyboardType: UIKeyboardType = .default) {
        self.keyboardType = keyboardType
    }
    
    func _body(configuration: TextField<_Label>) -> some View {
        configuration
            .padding(8)
            .background(.tertiary)
            .cornerRadius(6)
            .keyboardType(keyboardType)
            .autocorrectionDisabled()
            .textInputAutocapitalization(.never)
    }
}

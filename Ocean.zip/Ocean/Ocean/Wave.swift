//
//  Wave.swift
//  Ocean
//
//  Created by Maxime Lathiere on 16/11/2022.
//

import SwiftUI

struct Wave: Shape {
    var insets: (first: Double, second: Double)
    
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        path.move(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
        path.addCurve(to: CGPoint(x: rect.minX, y: rect.minY),
                      control1: CGPoint(x: rect.maxX * insets.first,
                                        y: rect.maxY * insets.second),
                      control2: CGPoint(x: rect.maxX * insets.second,
                                        y: rect.maxY * insets.first))
        path.closeSubpath()
        
        return path
    }
    
    var animatableData: AnimatablePair<Double, Double> {
        get {
            AnimatablePair(insets.first, insets.second)
        }
        set {
            insets.first = newValue.first
            insets.second = newValue.second
        }
    }
}
struct Wave_Previews: PreviewProvider {
    static var previews: some View {
        Wave(insets: (0.8, 0.2))
    }
}

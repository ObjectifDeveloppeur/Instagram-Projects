//
//  OceanApp.swift
//  Ocean
//
//  Created by Maxime Lathiere on 16/11/2022.
//

import SwiftUI

@main
struct OceanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

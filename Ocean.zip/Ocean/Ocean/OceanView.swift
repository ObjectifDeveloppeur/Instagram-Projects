//
//  OceanView.swift
//  Ocean
//
//  Created by Maxime Lathiere on 16/11/2022.
//

import SwiftUI

struct OceanView: View {
    @State private var isAnimated = false
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            ForEach(0..<5, id: \.self) { number in
                Wave(insets: insets)
                    .fill(.blue.opacity(isAnimated ? 0.6 : 0.2))
                    .frame(width: UIScreen.main.bounds.width * (1 - (0.1 * Double(number))))
            }
        }
        .ignoresSafeArea()
        .onAppear(perform: startAnimation)
    }
    
    private var insets: (Double, Double) {
        isAnimated ? (0.8, 0.2) : (0.2, 0.8)
    }
    
    private func startAnimation() {
        withAnimation(.easeInOut(duration: 10).repeatForever(autoreverses: true)) {
            isAnimated = true
        }
    }
}



struct OceanView_Previews: PreviewProvider {
    static var previews: some View {
        OceanView()
            .ignoresSafeArea()
    }
}



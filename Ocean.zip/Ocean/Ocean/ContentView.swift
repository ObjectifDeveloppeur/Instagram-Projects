//
//  ContentView.swift
//  Ocean
//
//  Created by Maxime Lathiere on 16/11/2022.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        OceanView()
            .ignoresSafeArea()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
